def anchor(hash_value):
    print("ANCHOR PLACEHOLDER")
    print("Hash:", hash_value)
    print("Ethereum / Bitcoin adapters come next")
